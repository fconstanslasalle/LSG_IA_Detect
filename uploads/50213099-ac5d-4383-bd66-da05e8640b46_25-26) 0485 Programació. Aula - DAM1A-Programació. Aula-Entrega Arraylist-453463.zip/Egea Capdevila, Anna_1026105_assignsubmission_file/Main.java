import java.util.ArrayList;
import java.util.Scanner;

public class Exercici1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Float> notesAlumnes = new ArrayList<>();
         
            boolean sortir = false;
            int opcio;

            while(!sortir) {
                System.out.println("1- Introduïr nota");
                System.out.println("2- Consultar nota");
                System.out.println("3- Eliminar nota");
                System.out.println("4- Modificar nota");
                System.out.println("5- Sortir");
            }
        System.out.println("Que cols fer? ");
            opcio= sc.nextInt();

            switch (opcio){
            case 1:
                System.out.println("Introduïr nota al final del llistat");
                break;
            case 2:
                System.out.println("Consultar la nota d'un índex");
                break;

                case 3:
                    System.out.println("Introduïr nota al final del llistat");
                    break;
                case 2:
                    System.out.println("Consultar la nota d'un índex");
                    break;


        }
        }









        //notesAlumnes.add(0.0f);
      //  notesAlumnes.add(1.0f);
       // notesAlumnes.add(2.0f);
       // notesAlumnes.add(3.0f);
       // notesAlumnes.add(4.0f);
      //  notesAlumnes.add(5.0f);
    //notesAlumnes.add(6.0f);
    //    notesAlumnes.add(7.0f);
    //  notesAlumnes.add(8.0f);
    //   notesAlumnes.add(9.0f);
    //  notesAlumnes.add(10.0f);

    // notesAlumnes.size(); // devuelve el tamaño del array

    //  notesAlumnes.remove(0); // borra el primero que es el 0

    //  notesAlumnes.set(1, 100); // cambia el

    //  for (int i = 0; i < notesAlumnes.size(); i++) {
    //    System.out.println(notesAlumnes.get(i)); // acceder al elemento

            //  for(Integer x: a){
                // System.out.println(x);
        }
    }
}
