import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Float input_nota = 0.0f;
        ArrayList<Float> notesAlumnes = new ArrayList<Float>();
        ArrayList<String> nomsAlumnes = new ArrayList<>();
        String[] noms = {"Maria", "Marta", "Alvaro", "Pau", "Irene", "Joel", "Ignasi", "Lucia", "Pepe", "Alicia", "Patricio"};
        for(int i = 0; i <= 10; i++) {
            float randomNota = (float) (Math.random() * 10.1f);
            notesAlumnes.add(randomNota);
            nomsAlumnes.add(noms[i]);
        }

        int opcion = 0, index = 0;

        do {
            System.out.println("Quina acció vols fer?: ");
            System.out.println("1. Introduïr nota al final del llistat notes");
            System.out.println("2. Consultar la nota d'un índex");
            System.out.println("3. Eliminar una nota en un índex");
            System.out.println("4. Modificar la nota en un índex notes");
            System.out.println("5. Sortir");

            opcion = sc.nextInt();

            if(1 < opcion && opcion <= 4) {
                do {
                    if(index < 0 || index > (notesAlumnes.size() - 1)) System.out.println("Error");

                    System.out.println("Posa un index entre 0 i " + (notesAlumnes.size() - 1) + ": ");
                    index = sc.nextInt();
                } while (index < 0 || index > (notesAlumnes.size() - 1));
            }

            switch (opcion) {
                case 1:
                    do {
                        if(input_nota < 0 || input_nota > 10) System.out.println("Error");
                        System.out.println("Escriu la nota que vols introduir: ");
                        input_nota = sc.nextFloat();
                        if(input_nota >= 0 && input_nota <= 10) notesAlumnes.add(input_nota);
                    } while (input_nota < 0 || input_nota > 10);

                    System.out.println("Escriu el nom de l'alumne: ");
                    nomsAlumnes.add(sc.next());
                    System.out.println("El tamany de la llista es de: " + notesAlumnes.size());
                    break;
                case 2:
                    System.out.println("Alumne: " + nomsAlumnes.get(index));
                    System.out.printf("Nota a consultar: %.2f ", notesAlumnes.get(index));
                    System.out.println();
                    break;
                case 3:
                    Float nota_esborrada = notesAlumnes.get(index);
                    String nom_esborrat = nomsAlumnes.get(index);
                    nomsAlumnes.remove(index);
                    notesAlumnes.remove(index);
                    System.out.printf("La nota de " + nom_esborrat + " s'ha esborrat: %.2f", nota_esborrada);
                    System.out.println("El tamany de la llista es de: " + notesAlumnes.size());
                    break;
                case 4:
                    Float nota_abans_modificar = notesAlumnes.get(index);
                    do {
                        System.out.println("Escriu la nova nota: ");
                        input_nota = sc.nextFloat();
                        if(input_nota >= 0 && input_nota <= 10) notesAlumnes.set(index, input_nota);
                    } while (input_nota < 0 || input_nota > 10);
                    
                    System.out.printf("La nota de " + nomsAlumnes.get(index) +": %.2f s'ha cambiat per: %.2f", nota_abans_modificar, notesAlumnes.get(index));
                    System.out.println();
                    break;
            }

        } while (opcion != 5);

    }
}