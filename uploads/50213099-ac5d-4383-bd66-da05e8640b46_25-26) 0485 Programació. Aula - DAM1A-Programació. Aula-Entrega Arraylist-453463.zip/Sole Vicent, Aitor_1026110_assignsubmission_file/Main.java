import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Float> notesalumnes = new ArrayList<>();
        int opcio;
        int index;
        float nota;

        do {
            System.out.println("1. Afegir nota");
            System.out.println("2. Veure nota (index)");
            System.out.println("3. Eliminar nota (index)");
            System.out.println("4. Modificar nota (index)");
            System.out.println("5. Sortir");
            System.out.print("Opció: ");

            while (!sc.hasNextInt()) {
                System.out.println("Has d'escriure un número!");
                sc.next();
            }
            opcio = sc.nextInt();

            switch (opcio) {

                case 1:
                    System.out.print("Nota? ");
                    nota = sc.nextFloat();
                    notesalumnes.add(nota);
                    System.out.println("Nota afegida.");
                    break;

                case 2:
                    System.out.print("Index? ");
                    index = sc.nextInt();
                    if (index >= 0 && index < notesalumnes.size()) {
                        System.out.println("Nota: " + notesalumnes.get(index));
                    } else {
                        System.out.println("Index fora de rang.");
                    }
                    break;

                case 3:
                    System.out.print("Index a eliminar? ");
                    index = sc.nextInt();
                    if (index >= 0 && index < notesalumnes.size()) {
                        notesalumnes.remove(index);
                        System.out.println("Nota eliminada.");
                    } else {
                        System.out.println("Index fora de rang.");
                    }
                    break;

                case 4:
                    System.out.print("Index a modificar? ");
                    index = sc.nextInt();
                    if (index >= 0 && index < notesalumnes.size()) {
                        System.out.print("Nova nota? ");
                        nota = sc.nextFloat();
                        notesalumnes.set(index, nota);
                        System.out.println("Nota modificada.");
                    } else {
                        System.out.println("Index fora de rang.");
                    }
                    break;

                case 5:
                    System.out.println("Sortint...");
                    break;

                default:
                    System.out.println("Opció no vàlida.");
            }

        } while (opcio != 5);

        sc.close();
    }
}
