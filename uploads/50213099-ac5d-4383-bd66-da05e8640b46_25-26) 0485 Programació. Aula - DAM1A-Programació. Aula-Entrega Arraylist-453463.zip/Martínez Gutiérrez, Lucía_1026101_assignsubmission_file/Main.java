import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Float> notas = new ArrayList<>();
        ArrayList<String> nombres = new ArrayList<>();
        int opcion = 0;

        while (opcion != 5) {
            System.out.println("\n ===== MENÚ =====");
            System.out.println("1. Agregar nota");
            System.out.println("2. Ver nota");
            System.out.println("3. Borrar nota");
            System.out.println("4. Cambiar nota");
            System.out.println("5. Salir");
            System.out.println("");

            System.out.print("Seleciona una opción: ");

            opcion = input.nextInt();
            input.nextLine();

            if (opcion == 1) {
                System.out.print("Nombre: ");
                String nombre = input.nextLine();

                System.out.print("Nota: ");
                float nota = input.nextFloat();
                input.nextLine();

                nombres.add(nombre);
                notas.add(nota);
                System.out.println("¡Agregado!");
            }

            else if (opcion == 2) {
                if (notas.isEmpty()) {
                    System.out.println("No hay notas");
                } else {
                    for (int i = 0; i < notas.size(); i++) {
                        System.out.println(i + ". " + nombres.get(i) + " - " + notas.get(i));
                    }
                }
            }

            else if (opcion == 3) {
                if (notas.isEmpty()) {
                    System.out.println("No hay notas");
                } else {
                    for (int i = 0; i < notas.size(); i++) {
                        System.out.println(i + ". " + nombres.get(i) + " - " + notas.get(i));
                    }

                    System.out.print("Borrar índice: ");
                    int indice = input.nextInt();
                    input.nextLine();

                    if (indice >= 0 && indice < notas.size()) {
                        nombres.remove(indice);
                        notas.remove(indice);
                        System.out.println("Borrado");
                    } else {
                        System.out.println("Índice incorrecto");
                    }
                }
            }

            else if (opcion == 4) {
                if (notas.isEmpty()) {
                    System.out.println("No hay notas");
                } else {
                    for (int i = 0; i < notas.size(); i++) {
                        System.out.println(i + ". " + nombres.get(i) + " - " + notas.get(i));
                    }

                    System.out.print("Cambiar índice: ");
                    int indice = input.nextInt();
                    input.nextLine();

                    if (indice >= 0 && indice < notas.size()) {
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = input.nextLine();
                        nombres.set(indice, nuevoNombre);

                        System.out.print("Nueva nota: ");
                        float nuevaNota = input.nextFloat();
                        input.nextLine();
                        notas.set(indice, nuevaNota);

                        System.out.println("Nota modificada correctamente");
                    } else {
                        System.out.println("Índice incorrecto");
                    }
                }
            }

            else if (opcion == 5) {
                System.out.println("Adiositooo");
            }

            else {
                System.out.println("Opción no válida");
            }
        }

        input.close();
    }
}