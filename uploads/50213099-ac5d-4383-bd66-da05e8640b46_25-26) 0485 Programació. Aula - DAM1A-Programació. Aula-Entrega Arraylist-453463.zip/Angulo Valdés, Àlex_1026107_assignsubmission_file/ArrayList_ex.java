import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        ArrayList<Float> notesAlumnes = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        int opcio = 0;
        

        do {
            System.out.println("1. Introduïr nota ");
            System.out.println("2. Consultar nota ");
            System.out.println("3. Eliminar nota ");
            System.out.println("4. Modificar nota ");
            System.out.println("5. Sortir");
            opcio = sc.nextInt();
            switch (opcio) {
                case 1:
                    System.out.print("Introdueix la nova nota (Float): ");
                    
                    if (sc.hasNextFloat()) {
                        Float nota = sc.nextFloat();
                        notesAlumnes.add(nota); 
                        System.out.println("Nota " + nota + " afegida a l'índex " + (notesAlumnes.size() - 1) + ".");
                    } else {
                        System.out.println("ERROR: La nota ha de ser un número.");
                    }
                    sc.nextLine();

                    break;

                case 2:

                    if (notesAlumnes.isEmpty()) { System.out.println("Llistat buit."); break; }
                    System.out.print("Índex a consultar (0 a " + (notesAlumnes.size() - 1) + "): ");
                    
                    if (sc.hasNextInt()) {
                        int index = sc.nextInt();
                        if (index >= 0 && index < notesAlumnes.size()) {
                            Float nota = notesAlumnes.get(index); 
                            System.out.println("Nota a l'índex " + index + ": " + nota);
                        } else {
                            System.out.println("ERROR: Índex fora de rang.");
                        }
                    } else { System.out.println("ERROR: Has d'introduir un número enter."); }
                    sc.nextLine(); 

                    break;
                    
                case 3:
                    if (notesAlumnes.isEmpty()) { System.out.println("Llistat buit."); break; }
                    System.out.print("Índex a eliminar (0 a " + (notesAlumnes.size() - 1) + "): ");
                    
                    if (sc.hasNextInt()) {
                        int index = sc.nextInt();
                        if (index >= 0 && index < notesAlumnes.size()) {
                            Float notaEliminada = notesAlumnes.remove(index); 
                            System.out.println("S'ha eliminat la nota " + notaEliminada + " de l'índex " + index + ".");
                        } else {
                            System.out.println("ERROR: Índex fora de rang.");
                        }
                    } else { System.out.println("ERROR: Has d'introduir un número enter."); }
                    sc.nextLine(); 

                    break;
                    
                case 4:
                    

                    break;
                    
                case 5:
                    System.out.println("Sortint de l'aplicació.");
                    break;
                    
                default:
                    System.out.println("Opció no vàlida. Torna a intentar-ho.");
            }
            
        } while (opcio != 0);
        
        sc.close();
    }
}