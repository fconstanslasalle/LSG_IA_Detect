import com.sun.jdi.request.InvalidRequestStateException;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Float> notasAlumnes = new ArrayList<>();

        while (true){
            System.out.print("\nQue vols fer?\n" +
                    "1 - Introduir una nota\n" +
                    "2 - Consultar una nota\n" +
                    "3 - Eliminar una nota\n" +
                    "4 - Modificar una nota\n" +
                    "5 - Qualsevol altre tecla per sortir.\n");
            int opcio = sc.nextInt();
            switch(opcio){
                case 1:
                    System.out.print("Introdueix una nota: ");
                    float nota = sc.nextFloat();
                    notasAlumnes.add(nota);
                    break;

                case 2:
                    System.out.print("Quina posició està la nota? ");
                    nota = sc.nextInt();
                    System.out.println("\nLa nota seleccionada es: " + notasAlumnes.get((int) nota));
                    break;

                case 3:
                    System.out.print("Elimina una nota: ");
                    nota = sc.nextInt();
                    notasAlumnes.remove((int) nota);
                    break;

                case 4:
                    System.out.print("A quina posicio està la nota que vols canviar: ");
                    nota = sc.nextInt();
                    System.out.println("Quina nota vols introduir com a nova?");
                    float canvi = sc.nextInt();
                    notasAlumnes.set((int) nota, canvi);
                    break;

                case 5:
                    System.out.print("Sortint...");
                    break;

                default:
                    System.out.println("Invalid option");
                    break;
            }
        }
    }
}