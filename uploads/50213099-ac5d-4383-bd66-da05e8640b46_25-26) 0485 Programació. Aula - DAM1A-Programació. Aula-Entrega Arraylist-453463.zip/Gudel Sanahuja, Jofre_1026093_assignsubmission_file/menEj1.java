import java.util.ArrayList;
import java.util.Scanner;

public class menEj1 {

    public static void main(String[] args) {

        Scanner sca = new Scanner(System.in);
        ArrayList<Float> notesAlumnes  = new ArrayList<>();
        int opcionEsco;

        do
        {
            System.out.print("");
            System.out.println("Menu");/* Si alguien se pregunta que es eso (en el caso de que os lo pregunteis), es para que no quede todo junto. Simplemente es que me da un poco de toc que se quede todo juntito :)*/
            System.out.println("1. Afegir nota");
            System.out.println("2. Consultar nota");
            System.out.println("3. Eliminar nota");
            System.out.println("4. Modificar nota");
            System.out.println("0. Sortir");
            System.out.print("Que opcion seleccionars? ");
            opcionEsco = sca.nextInt();
            System.out.println(""); /*igual que esta*/

            if (opcionEsco == 1)
            {
                System.out.print("Introduce la nota: ");
                float nota = sca.nextFloat();
                notesAlumnes.add(nota);
                System.out.println("Nota agregada");
                System.out.println("");
            }
            else
            if (opcionEsco == 2)
            {
                System.out.print("Que indice quieres ver?: ");
                int indicecito = sca.nextInt();

                if (indicecito >= 0 && indicecito < notesAlumnes.size())
                    System.out.println("Nota: " + notesAlumnes.get(indicecito));
                else
                    System.out.println("Incorrecto");
            }
            else
                if (opcionEsco == 3)
                {
                System.out.print("Que indice quieres borrar?: ");
                int indicecito = sca.nextInt();

                if (indicecito >= 0 && indicecito < notesAlumnes.size())
                {
                    notesAlumnes.remove(indicecito);
                    System.out.println("Nota borrada");
                    System.out.print("");
                }
                else
                {
                    System.out.println("Incorrecto");
                }
            }

            else
                if (opcionEsco == 4)
                {
                System.out.print("Que indice queires cambiar?: ");
                int indicecito = sca.nextInt();

                if (indicecito >= 0 && indicecito < notesAlumnes.size()) 
                {
                    System.out.print("Nueva nota: ");
                    float notaNuevecita = sca.nextFloat();
                    notesAlumnes.set(indicecito, notaNuevecita);
                    System.out.println("Nota cambiada");
                    System.out.print("");
                }
                else
                {
                    System.out.println("Incorrecto");
                }
            }

        } 
        while (opcionEsco != 0);
        System.out.println("Fin del programa :)");
    }
}