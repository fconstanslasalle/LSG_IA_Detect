import java.util.Scanner;
import java.util.ArrayList;

public class arraylist {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<Float> notas = new ArrayList<Float>();
        int salir = 0;

        while (salir == 0) {
            System.out.println("1. Introducir nota");
            System.out.println("2. Consultar nota");
            System.out.println("3. Eliminar nota");
            System.out.println("4. Modificar nota");
            System.out.println("5. Salir");
            System.out.print("Que accion quieres hacer : ");
            int caso = scan.nextInt();

            switch (caso) {
                case 1:
                    System.out.println("Has selecionado introducir una nota");
                    float nota = scan.nextFloat();
                    notas.add(nota);
                    break;

                case 2:
                    System.out.println("Has selecionado consultar una nota");
                    int p_consultar = scan.nextInt();
                    System.out.println(notas.get(p_consultar));
                    break;

                case 3:
                    System.out.println("Has selecionado eliminar una nota");
                    int p_eliminar = scan.nextInt();
                    notas.remove(p_eliminar);
                    break;

                case 4:
                    System.out.println("Has selecionado modificar una nota");
                    int p_modificar = scan.nextInt();
                    float n_cambiar = scan.nextFloat();
                    notas.set(p_modificar, n_cambiar);
                    break;

                case 5:
                    System.out.println("Saliendo...");
                    salir = 1;
                    break;

                default:
                    System.out.println("Has seleccionado una opcion no valida");
                    break;
            }

        }

        scan.close();
    }
}
