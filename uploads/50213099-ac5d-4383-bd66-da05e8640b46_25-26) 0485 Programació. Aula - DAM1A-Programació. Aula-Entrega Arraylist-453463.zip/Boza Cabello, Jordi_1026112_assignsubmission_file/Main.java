import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static ArrayList<Float> notes = new ArrayList<>();
    private static ArrayList<String> noms = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcio;
        do {
            System.out.println("MENÚ DE NOTAS");
            System.out.println("1. Introducir nota");
            System.out.println("2. Consultar nota");
            System.out.println("3. Eliminar nota");
            System.out.println("4. Modificar nota");
            System.out.println("5. Mostrar todas");
            System.out.println("6. Salir");
            System.out.print("Opción: ");
            opcio = scanner.nextInt();
            scanner.nextLine();

            switch (opcio) {
                case 1:
                    introduir();
                    break;
                case 2:
                    consultar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    modificar();
                    break;
                case 5:
                    mostrar();
                    break;
            }
        } while (opcio != 6);
        scanner.close();
    }

    private static void introduir() {
        System.out.print("Nom: ");
        noms.add(scanner.nextLine());
        System.out.print("Nota (0-10): ");
        notes.add(scanner.nextFloat());
        scanner.nextLine();
    }

    private static void consultar() {
        if (notes.isEmpty()) {
            System.out.println("No hi ha notes");
            return;
        }
        mostrar();
        System.out.print("Índex: ");
        int i = scanner.nextInt();
        scanner.nextLine();
        if (i >= 0 && i < notes.size())
            System.out.println(noms.get(i) + ": " + notes.get(i));
    }

    private static void eliminar() {
        if (notes.isEmpty()) {
            System.out.println("No hi ha notes");
            return;
        }
        mostrar();
        System.out.print("Índex a eliminar: ");
        int i = scanner.nextInt();
        scanner.nextLine();
        if (i >= 0 && i < notes.size()) {
            noms.remove(i);
            notes.remove(i);
        }
    }

    private static void modificar() {
        if (notes.isEmpty()) {
            System.out.println("No hi ha notes");
            return;
        }
        mostrar();
        System.out.print("Índex a modificar: ");
        int i = scanner.nextInt();
        scanner.nextLine();
        if (i >= 0 && i < notes.size()) {
            System.out.print("Nou nom (actual: " + noms.get(i) + "): ");
            noms.set(i, scanner.nextLine());
            System.out.print("Nova nota (actual: " + notes.get(i) + "): ");
            notes.set(i, scanner.nextFloat());
            scanner.nextLine();
        }
    }

    private static void mostrar() {
        if (notes.isEmpty()) {
            System.out.println("No hi ha notes");
            return;
        }
        for (int i = 0; i < notes.size(); i++)
            System.out.println(i + ". " + noms.get(i) + " - " + notes.get(i));
    }
}