import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner marc = new Scanner(System.in);
        ArrayList<Float> notesAlumnes = new ArrayList<>();
        int opcio;
        
        do {
            System.out.println("1. Introduir nota");
            System.out.println("2. Consultar nota");
            System.out.println("3. Eliminar nota");
            System.out.println("4. Modificar nota");
            System.out.println("5. Sortir");
            System.out.print("Tria: ");
            opcio = marc.nextInt();
            
            switch(opcio) {
                case 1:
                    System.out.print("Nota: ");
                    float nota = marc.nextFloat();
                    notesAlumnes.add(nota);
                    break;
                    
                case 2:
                    if(notesAlumnes.size() == 0) {
                        System.out.println("No hi ha notes");
                    } else {
                        System.out.print("Index: ");
                        int index = marc.nextInt();
                        if(index >= 0 && index < notesAlumnes.size()) {
                            System.out.println("Nota: " + notesAlumnes.get(index));
                        } else {
                            System.out.println("Error: index fora de rang");
                        }
                    }
                    break;
                    
                case 3:
                    if(notesAlumnes.size() == 0) {
                        System.out.println("No hi ha notes");
                    } else {
                        System.out.print("Index: ");
                        int index = marc.nextInt();
                        if(index >= 0 && index < notesAlumnes.size()) {
                            notesAlumnes.remove(index);
                            System.out.println("Eliminada");
                        } else {
                            System.out.println("Error: index fora de rang");
                        }
                    }
                    break;
                    
                case 4:
                    if(notesAlumnes.size() == 0) {
                        System.out.println("No hi ha notes");
                    } else {
                        System.out.print("Index: ");
                        int index = marc.nextInt();
                        if(index >= 0 && index < notesAlumnes.size()) {
                            System.out.print("Nova nota: ");
                            float novaNota = marc.nextFloat();
                            notesAlumnes.set(index, novaNota);
                            System.out.println("Modificada");
                        } else {
                            System.out.println("Error: index fora de rang");
                        }
                    }
                    break;
                    
                case 5:
                    System.out.println("Adeu!");
                    break;
                    
                default:
                    System.out.println("Opció incorrecta (1-5)");
            }
            
        } while(opcio != 5);
        
        marc.close();
    }
}