import org.w3c.dom.Notation;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        float nota = 0;
        int a = 0;

        ArrayList<Float> notesAlumnes = new ArrayList<Float>();

        while (nota >= 0 && nota <= 10) {

            switch (a >= 0 && a <= 10) {
                case 1:
                    System.out.println("Introduir nota");
                    notesAlumnes.add(nota);
                    break;

                case 2:
                    System.out.println("Consultar nota");
                    notesAlumnes.get(nota);
                    break;

                case 3:
                    System.out.println("Eliminar nota");

                    break;

                case 4:
                    System.out.println("Modificar nota");
                    break;

                case 5:
                    System.out.println("Sortir");
                    break;
            }

        }

    }
}